module.exports = {
    crawler : require('./api/routes/category/crawler'),
    search : require('./api/routes/search/search'),
    user : require('./api/routes/user/user'),
    reStartSchedule: require('./api/routes/reStartSchedule/reStartSchedule')
}