module.exports = {
    Jwt_sect:"DFSADHDSFJH23^Q#$&$%ERIJHE"
}